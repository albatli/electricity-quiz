import { useState, useRef, useEffect } from "react";

const questions = [
  { q: "ما هو الجهاز الذي يستهلك النسبة الأكبر من فاتورة كهرباء المنزل (حوالي 85%)؟", opts: ["السخان الكهربائي", "المكيفات", "الثلاجة", "غسالة الصحون"], correct: 1 },
  { q: "كم تبلغ التكلفة الشهرية التقريبية لتشغيل المودم (الراوتر) على مدار 24 ساعة يومياً؟", opts: ["15 ريال", "5 ريال", "ريال واحد تقريباً", "10 ريال"], correct: 2 },
  { q: "بالنسبة لسخان الماء، ما هو التصرف الصحيح والأوفر لاستهلاك الكهرباء؟", opts: ["إبقاؤه يعمل طوال الوقت ليحافظ على الحرارة", "إطفاؤه وتشغيله فقط عند الحاجة", "الاستهلاك ثابت في الحالتين"], correct: 1 },
  { q: "ما هي درجة الحرارة المثالية الموصى بها لضبط مؤشر سخان الماء لتقليل الاستهلاك؟", opts: ["70 إلى 80 درجة", "50 إلى 60 درجة", "40 إلى 45 درجة", "90 درجة"], correct: 1 },
  { q: "كم تبلغ تكلفة تشغيل غسالة الملابس للغسلة الواحدة (لمدة ساعة تقريباً)؟", opts: ["ريال واحد", "4 هللات", "50 هللة", "ريالان"], correct: 1 },
  { q: "من خلال تجربة قياس الاستهلاك، أيهما يستهلك كهرباء أقل؟", opts: ["مكيف الشباك القديم", "مكيف السبليت الحديث", "الاستهلاك متطابق في كليهما"], correct: 1 },
  { q: "أي من هذه العوامل يُعتبر من أكبر أسباب تسرب الهواء البارد وزيادة عمل كمبروسر المكيف؟", opts: ["عدم تنظيف الفلاتر", "ترك الأبواب مفتوحة بشكل مستمر", "إطفاء مروحة الشفط في دورة المياه"], correct: 1 },
  { q: "كم تبلغ تكلفة الثلاجة المشتغلة على مدار 24 ساعة في الشهر تقريباً؟", opts: ["12 ريال", "50 ريال", "100 ريال", "5 ريال"], correct: 0 },
  { q: "كم يكلف تشغيل غلاية الماء لمدة ساعتين باليوم خلال شهر كامل؟", opts: ["5 ريال", "10 ريال", "20 ريال", "40 ريال"], correct: 2 },
  { q: "هل مقولة 'مروحة الشفط تسحب الهواء البارد من الغرفة إلى الخارج' صحيحة أم خاطئة؟", opts: ["صحيحة، وتزيد من استهلاك المكيف", "خاطئة، مروحة الشفط لا تؤثر على تبريد الغرفة"], correct: 0 },
];

const KEY = "elec_quiz_lb_v2";
const medals = ["🥇","🥈","🥉"];

function getRank(pct) {
  if (pct === 100) return { label:"خبير الكهرباء", color:"#1D9E75", bg:"#E1F5EE" };
  if (pct >= 80)   return { label:"متميز",          color:"#185FA5", bg:"#E6F1FB" };
  if (pct >= 60)   return { label:"جيد",             color:"#BA7517", bg:"#FAEEDA" };
  return                   { label:"تحتاج مراجعة",   color:"#993C1D", bg:"#FAECE7" };
}

function readLB()    { try { return JSON.parse(localStorage.getItem(KEY)||"[]"); } catch { return []; } }
function writeLB(lb) { try { localStorage.setItem(KEY, JSON.stringify(lb)); } catch {} }

export default function App() {
  const [screen, setScreen]           = useState("start");
  const [playerName, setPlayerName]   = useState("");
  const [currentQ, setCurrentQ]       = useState(0);
  const [selected, setSelected]       = useState(null);
  const [lb, setLb]                   = useState([]);
  const [finalScore, setFinalScore]   = useState(0);
  const scoreRef                      = useRef(0);

  useEffect(() => { setLb(readLB()); }, []);

  function addEntry(name, score) {
    const entry = { name, score, pct: Math.round((score / questions.length) * 100) };
    const next  = [...readLB(), entry].sort((a,b) => b.pct - a.pct || a.name.localeCompare(b.name)).slice(0,50);
    writeLB(next);
    setLb(next);
  }

  function start() {
    if (!playerName.trim()) return;
    scoreRef.current = 0;
    setCurrentQ(0); setSelected(null); setFinalScore(0); setScreen("quiz");
  }

  function pick(i) {
    if (selected !== null) return;
    setSelected(i);
    if (i === questions[currentQ].correct) scoreRef.current++;
    setTimeout(() => {
      const next = currentQ + 1;
      if (next >= questions.length) {
        const s = scoreRef.current;
        setFinalScore(s);
        addEntry(playerName, s);
        setScreen("result");
      } else {
        setCurrentQ(next); setSelected(null);
      }
    }, 280);
  }

  function restart() {
    scoreRef.current = 0;
    setCurrentQ(0); setSelected(null); setFinalScore(0); setPlayerName("");
    setLb(readLB()); setScreen("start");
  }

  const progPct  = Math.round((currentQ / questions.length) * 100);
  const finalPct = Math.round((finalScore / questions.length) * 100);
  const rank     = getRank(finalPct);

  const c = {
    page:   { direction:"rtl", fontFamily:"'Segoe UI',Tahoma,Arial,sans-serif", maxWidth:520, margin:"0 auto", padding:"1.5rem 1rem" },
    card:   { background:"#fff", borderRadius:16, border:"1px solid #e8e8e8", padding:"1.25rem 1.5rem", marginBottom:"1rem" },
    input:  { width:"100%", padding:"0.65rem 0.9rem", borderRadius:10, border:"1px solid #ddd", fontSize:15, textAlign:"right", direction:"rtl", outline:"none", background:"#fafafa", boxSizing:"border-box", marginBottom:"1rem" },
    green:  { width:"100%", padding:"0.75rem", borderRadius:10, border:"none", background:"#1D9E75", color:"#fff", fontSize:16, fontWeight:600, cursor:"pointer" },
    opt:    (on) => ({ display:"block", textAlign:"right", width:"100%", padding:"0.75rem 1rem", borderRadius:10, border:`1px solid ${on?"#aaa":"#e0e0e0"}`, background:on?"#f0f0f0":"#fafafa", color:"#1a1a1a", fontSize:15, cursor:"pointer", marginBottom:8, opacity:on?0.6:1, transition:"all 0.15s" }),
    grid2:  { display:"grid", gridTemplateColumns:"1fr 1fr", gap:10, margin:"1rem 0" },
    stat:   { background:"#fafafa", borderRadius:10, padding:"0.75rem 1rem", textAlign:"center", border:"1px solid #eee" },
    lbRow:  (me) => ({ display:"flex", alignItems:"center", gap:10, padding:"0.5rem", borderRadius:8, background:me?"#E1F5EE":"transparent", marginBottom:2 }),
    lbNum:  (i)  => ({ width:28, height:28, borderRadius:"50%", background:i===0?"#FAC775":i===1?"#e0e0e0":"#f0f0f0", display:"flex", alignItems:"center", justifyContent:"center", fontSize:i<3?14:12, fontWeight:600, color:i===0?"#633806":"#555", flexShrink:0 }),
  };

  if (screen === "start") return (
    <div style={c.page}>
      <div style={{ fontSize:36, textAlign:"center", marginBottom:6 }}>⚡</div>
      <div style={{ fontSize:20, fontWeight:700, textAlign:"center", color:"#1a1a1a", marginBottom:4 }}>اختبار الكهرباء المنزلية</div>
      <div style={{ fontSize:13, color:"#888", textAlign:"center", marginBottom:"1.5rem" }}>10 أسئلة · اكتشف أين تذهب فاتورتك</div>
      <div style={c.card}>
        <label style={{ fontSize:13, color:"#888", marginBottom:6, display:"block" }}>اسمك</label>
        <input style={c.input} placeholder="أدخل اسمك..." value={playerName}
          onChange={e => setPlayerName(e.target.value)} onKeyDown={e => e.key==="Enter" && start()} maxLength={30} />
        <button style={c.green} onClick={start}>ابدأ الاختبار ←</button>
      </div>
      <div style={c.card}>
        <div style={{ fontSize:13, color:"#888", fontWeight:600, marginBottom:"0.75rem" }}>لوحة المتصدرين</div>
        {lb.length === 0
          ? <div style={{ textAlign:"center", color:"#aaa", fontSize:14, padding:"1rem 0" }}>لا يوجد مشاركون بعد — كن الأول!</div>
          : lb.slice(0,5).map((e,i) => (
              <div key={i} style={c.lbRow(false)}>
                <div style={c.lbNum(i)}>{i<3?medals[i]:i+1}</div>
                <div style={{ flex:1, fontSize:14, color:"#1a1a1a" }}>{e.name}</div>
                <div style={{ fontSize:14, fontWeight:700, color:"#1D9E75" }}>{e.pct}%</div>
              </div>
            ))
        }
      </div>
    </div>
  );

  if (screen === "quiz") {
    const q = questions[currentQ];
    return (
      <div style={c.page}>
        <div style={{ background:"#f0f0f0", borderRadius:999, height:6, marginBottom:"1rem" }}>
          <div style={{ background:"#1D9E75", height:6, borderRadius:999, width:`${progPct}%`, transition:"width 0.3s" }} />
        </div>
        <div style={{ fontSize:12, color:"#aaa", marginBottom:6 }}>سؤال {currentQ+1} من {questions.length}</div>
        <div style={c.card}>
          <div style={{ fontSize:17, fontWeight:600, color:"#1a1a1a", lineHeight:1.6, marginBottom:"1.25rem" }}>{q.q}</div>
          {q.opts.map((opt,i) => (
            <button key={i} style={c.opt(selected===i)} onClick={() => pick(i)} disabled={selected!==null}>{opt}</button>
          ))}
        </div>
      </div>
    );
  }

  if (screen === "result") {
    const meIdx   = lb.findIndex(e => e.name===playerName && e.pct===finalPct);
    const highest = lb[0];
    const lowest  = lb[lb.length-1];
    return (
      <div style={c.page}>
        <div style={{ fontSize:36, textAlign:"center", marginBottom:6 }}>🎯</div>
        <div style={{ fontSize:20, fontWeight:700, textAlign:"center", color:"#1a1a1a", marginBottom:"1rem" }}>نتيجتك</div>
        <div style={c.card}>
          <div style={{ fontSize:56, fontWeight:800, color:"#1D9E75", textAlign:"center", lineHeight:1, marginBottom:4 }}>{finalPct}%</div>
          <div style={{ fontSize:14, color:"#888", textAlign:"center", marginBottom:10 }}>{finalScore} من {questions.length} إجابة صحيحة</div>
          <div style={{ textAlign:"center", marginBottom:"0.75rem" }}>
            <span style={{ display:"inline-block", padding:"4px 14px", borderRadius:999, fontSize:13, fontWeight:600, background:rank.bg, color:rank.color }}>{rank.label}</span>
          </div>
          <div style={c.grid2}>
            <div style={c.stat}><div style={{ fontSize:22, fontWeight:700, color:"#1D9E75" }}>{finalScore}</div><div style={{ fontSize:12, color:"#888", marginTop:2 }}>إجابات صحيحة</div></div>
            <div style={c.stat}><div style={{ fontSize:22, fontWeight:700, color:"#D85A30" }}>{questions.length-finalScore}</div><div style={{ fontSize:12, color:"#888", marginTop:2 }}>إجابات خاطئة</div></div>
            <div style={c.stat}><div style={{ fontSize:18, fontWeight:700 }}>{meIdx>=0?meIdx+1:"-"}</div><div style={{ fontSize:12, color:"#888", marginTop:2 }}>ترتيبك</div></div>
            <div style={c.stat}><div style={{ fontSize:18, fontWeight:700 }}>{lb.length}</div><div style={{ fontSize:12, color:"#888", marginTop:2 }}>عدد المشاركين</div></div>
          </div>
          {lb.length > 0 && (
            <div style={{ display:"flex", gap:10 }}>
              <div style={{ ...c.stat, flex:1, textAlign:"right" }}>
                <div style={{ fontSize:11, color:"#aaa", marginBottom:2 }}>🏆 أعلى درجة</div>
                <div style={{ fontSize:14, fontWeight:600 }}>{highest.name}</div>
                <div style={{ fontSize:13, color:"#1D9E75", fontWeight:700 }}>{highest.pct}%</div>
              </div>
              <div style={{ ...c.stat, flex:1, textAlign:"right" }}>
                <div style={{ fontSize:11, color:"#aaa", marginBottom:2 }}>📊 أدنى درجة</div>
                <div style={{ fontSize:14, fontWeight:600 }}>{lowest.name}</div>
                <div style={{ fontSize:13, color:"#D85A30", fontWeight:700 }}>{lowest.pct}%</div>
              </div>
            </div>
          )}
        </div>
        <div style={c.card}>
          <div style={{ fontSize:13, color:"#888", fontWeight:600, marginBottom:"0.75rem" }}>لوحة المتصدرين</div>
          {lb.slice(0,15).map((e,i) => {
            const me = i===meIdx;
            return (
              <div key={i} style={c.lbRow(me)}>
                <div style={c.lbNum(i)}>{i<3?medals[i]:i+1}</div>
                <div style={{ flex:1, fontSize:14, color:"#1a1a1a", fontWeight:me?700:400 }}>
                  {e.name}{me && <span style={{ fontSize:11, color:"#1D9E75", marginRight:6 }}>(أنت)</span>}
                </div>
                <div style={{ fontSize:14, fontWeight:700, color:i===0?"#1D9E75":"#555" }}>{e.pct}%</div>
              </div>
            );
          })}
        </div>
        <button style={c.green} onClick={restart}>شارك مجدداً ←</button>
      </div>
    );
  }
  return null;
}
